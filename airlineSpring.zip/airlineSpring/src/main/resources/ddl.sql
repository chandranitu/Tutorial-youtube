create table airline(Year int,Month int,DayofMonth int,DayOfWeek int,DepTime VARCHAR(100),CRSDepTime VARCHAR(100),ArrTime VARCHAR(100),CRSArrTime VARCHAR(100),
UniqueCarrier VARCHAR(100),FlightNum int,TailNum int,ActualElapsedTime int,CRSElapsedTime int,AirTime int,ArrDelay int,DepDelay int,Origin VARCHAR(100),
Dest VARCHAR(100),Distance int,TaxiIn int,TaxiOut int,Cancelled boolean,CancellationCode VARCHAR(100),Diverted boolean,CarrierDelay int,WeatherDelay int,
NASDelay int,SecurityDelay int,LateAircraftDelay int);
