package com.airline.listener;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.airline.dto.AirlineDTO;

/**
 * The listener interface for receiving job events.
 * The class that is interested in processing a job
 * event implements this interface, and the object created
 * with that class is registered with a component using the
 * component's <code>addJobListener<code> method. When
 * the job event occurs, that object's appropriate
 * method is invoked.
 *
 * @see JobEvent
 */
@Component
public class JobListener extends JobExecutionListenerSupport {

    /** The jdbc template. */
    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public JobListener(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    @Override
    public void afterJob(JobExecution jobExecution) {
        if(jobExecution.getStatus() == BatchStatus.COMPLETED) {
            jdbcTemplate.query("select Year ,Month ,DayofMonth ,DayOfWeek ,DepTime ,CRSDepTime ,ArrTime ,CRSArrTime ,\n"
            		+ "UniqueCarrier ,FlightNum ,TailNum ,ActualElapsedTime ,CRSElapsedTime ,AirTime ,ArrDelay ,DepDelay ,Origin ,\n"
            		+ "Dest ,Distance ,TaxiIn ,TaxiOut ,Cancelled ,CancellationCode ,Diverted ,CarrierDelay ,WeatherDelay ,\n"
            		+ "NASDelay ,SecurityDelay ,LateAircraftDelay from  airline ",
                (rs,rowNum)->{
                	return new AirlineDTO(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getInt(4),
                            rs.getString(5),rs.getString(6), rs.getString(7),rs.getString(8),rs.getString(9),
                            rs.getInt(10),rs.getInt(11), rs.getInt(12),rs.getInt(13),rs.getInt(14),
                            rs.getInt(15),rs.getInt(16), rs.getString(17),rs.getString(18),rs.getInt(19),
                            rs.getInt(20),rs.getInt(21), rs.getBoolean(22),rs.getString(23),rs.getBoolean(24),
                            rs.getInt(25), rs.getInt(26),rs.getInt(27),rs.getInt(28),rs.getInt(29));
                    }
                    );
        }
    }
}
