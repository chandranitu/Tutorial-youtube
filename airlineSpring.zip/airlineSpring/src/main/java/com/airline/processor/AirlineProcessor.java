package com.airline.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.airline.dto.AirlineDTO;
import com.airline.model.AirlineModel;

/**
 * The Class AirlineProcessor.
 * <p>
 * Class description explaining the usage.
 * </p>
 *
 * @author chandra
 */
public class AirlineProcessor implements ItemProcessor<AirlineModel, AirlineDTO> {

    /** The Constant LOGGER. */
    private static final Logger LOGGER = LoggerFactory.getLogger(AirlineProcessor.class);

    @Override
    public AirlineDTO process(final AirlineModel airlineModel) throws Exception {

        LOGGER.info("Transforming AirlineModel(s) to AirlineDTO(s)..");

        final AirlineDTO airlineDTO = new AirlineDTO(airlineModel.getYear(),airlineModel.getMonth(),airlineModel.getDayofMonth(),airlineModel.getDayOfWeek(),airlineModel.getDepTime(),
        		 airlineModel.getcRSDepTime(),airlineModel.getArrTime(),airlineModel.getcRSArrTime(),airlineModel.getUniqueCarrier(),airlineModel.getFlightNum(),
        		 airlineModel.getTailNum(),airlineModel.getActualElapsedTime(),airlineModel.getcRSElapsedTime(),airlineModel.getAirTime(),airlineModel.getArrDelay(),
        		 airlineModel.getDepDelay(),airlineModel.getOrigin(),airlineModel.getDest(),airlineModel.getDistance(),airlineModel.getTaxiIn(),
        		 airlineModel.getTaxiOut(),airlineModel.isCancelled(),airlineModel.getCancellationCode(),airlineModel.isDiverted(),airlineModel.getCarrierDelay(),
        		 airlineModel.getWeatherDelay(),airlineModel.getnASDelay(),airlineModel.getSecurityDelay(),airlineModel.getLateAircraftDelay());

        return airlineDTO;
    }

}
