package com.airline.dto;

import java.io.Serializable;

/**
 * The Class AirlineDTO.
 * <p>
 * Class description explaining the usage.
 * </p>
 *
 * @author chandra
 */
public class AirlineDTO implements Serializable {

	/**
	 * long holds the serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
//29
	private int year;
	private int month;
	private int dayofMonth;
	private int dayOfWeek;
	private String depTime;
	private String cRSDepTime;
	private String arrTime;
	private String cRSArrTime;
	private String uniqueCarrier;
	private int flightNum;
	private int tailNum;
	private int actualElapsedTime;
	private int cRSElapsedTime;
	private int airTime;
	private int arrDelay;
	private int depDelay;
	private String origin;
	private String dest;
	private int distance;
	private int taxiIn;
	private int taxiOut;
	private boolean cancelled;
	private String cancellationCode;
	private boolean diverted;
	private int carrierDelay;
	private int weatherDelay;
	private int nASDelay;
	private int securityDelay;
	private int lateAircraftDelay;

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getDayofMonth() {
		return dayofMonth;
	}

	public void setDayofMonth(int dayofMonth) {
		this.dayofMonth = dayofMonth;
	}

	public int getDayOfWeek() {
		return dayOfWeek;
	}

	public void setDayOfWeek(int dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}

	public String getDepTime() {
		return depTime;
	}

	public void setDepTime(String depTime) {
		this.depTime = depTime;
	}

	public String getcRSDepTime() {
		return cRSDepTime;
	}

	public void setcRSDepTime(String cRSDepTime) {
		this.cRSDepTime = cRSDepTime;
	}

	public String getArrTime() {
		return arrTime;
	}

	public void setArrTime(String arrTime) {
		this.arrTime = arrTime;
	}

	public String getcRSArrTime() {
		return cRSArrTime;
	}

	public void setcRSArrTime(String cRSArrTime) {
		this.cRSArrTime = cRSArrTime;
	}

	public String getUniqueCarrier() {
		return uniqueCarrier;
	}

	public void setUniqueCarrier(String uniqueCarrier) {
		this.uniqueCarrier = uniqueCarrier;
	}

	public int getFlightNum() {
		return flightNum;
	}

	public void setFlightNum(int flightNum) {
		this.flightNum = flightNum;
	}

	public int getTailNum() {
		return tailNum;
	}

	public void setTailNum(int tailNum) {
		this.tailNum = tailNum;
	}

	public int getActualElapsedTime() {
		return actualElapsedTime;
	}

	public void setActualElapsedTime(int actualElapsedTime) {
		this.actualElapsedTime = actualElapsedTime;
	}

	public int getcRSElapsedTime() {
		return cRSElapsedTime;
	}

	public void setcRSElapsedTime(int cRSElapsedTime) {
		this.cRSElapsedTime = cRSElapsedTime;
	}

	public int getAirTime() {
		return airTime;
	}

	public void setAirTime(int airTime) {
		this.airTime = airTime;
	}

	public int getArrDelay() {
		return arrDelay;
	}

	public void setArrDelay(int arrDelay) {
		this.arrDelay = arrDelay;
	}

	public int getDepDelay() {
		return depDelay;
	}

	public void setDepDelay(int depDelay) {
		this.depDelay = depDelay;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDest() {
		return dest;
	}

	public void setDest(String dest) {
		this.dest = dest;
	}

	public int getDistance() {
		return distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}

	public int getTaxiIn() {
		return taxiIn;
	}

	public void setTaxiIn(int taxiIn) {
		this.taxiIn = taxiIn;
	}

	public int getTaxiOut() {
		return taxiOut;
	}

	public void setTaxiOut(int taxiOut) {
		this.taxiOut = taxiOut;
	}

	public boolean isCancelled() {
		return cancelled;
	}

	public void setCancelled(boolean cancelled) {
		this.cancelled = cancelled;
	}

	public String getCancellationCode() {
		return cancellationCode;
	}

	public void setCancellationCode(String cancellationCode) {
		this.cancellationCode = cancellationCode;
	}

	public boolean isDiverted() {
		return diverted;
	}

	public void setDiverted(boolean diverted) {
		this.diverted = diverted;
	}

	public int getCarrierDelay() {
		return carrierDelay;
	}

	public void setCarrierDelay(int carrierDelay) {
		this.carrierDelay = carrierDelay;
	}

	public int getWeatherDelay() {
		return weatherDelay;
	}

	public void setWeatherDelay(int weatherDelay) {
		this.weatherDelay = weatherDelay;
	}

	public int getnASDelay() {
		return nASDelay;
	}

	public void setnASDelay(int nASDelay) {
		this.nASDelay = nASDelay;
	}

	public int getSecurityDelay() {
		return securityDelay;
	}

	public void setSecurityDelay(int securityDelay) {
		this.securityDelay = securityDelay;
	}

	public int getLateAircraftDelay() {
		return lateAircraftDelay;
	}

	public void setLateAircraftDelay(int lateAircraftDelay) {
		this.lateAircraftDelay = lateAircraftDelay;
	}

	public AirlineDTO( int year, int month, int dayofMonth, int dayOfWeek, String depTime, String cRSDepTime, String arrTime, String cRSArrTime, String uniqueCarrier, int flightNum, int tailNum, int actualElapsedTime, int cRSElapsedTime,
			 int airTime, int arrDelay, int depDelay, String origin, String dest, int distance, int taxiIn, int taxiOut, boolean cancelled, String cancellationCode, boolean diverted, int carrierDelay, int weatherDelay, int nASDelay, int securityDelay,
			 int lateAircraftDelay) {
		this.year = year;
		this.month = month;
		this.dayofMonth = dayofMonth;
		this.dayOfWeek = dayOfWeek;
		this.depTime = depTime;
		this.cRSDepTime = cRSDepTime;
		this.arrTime = arrTime;
		this.cRSArrTime = cRSArrTime;
		this.uniqueCarrier = uniqueCarrier;
		this.flightNum = flightNum;
		this.tailNum = tailNum;
		this.actualElapsedTime = actualElapsedTime;
		this.cRSElapsedTime = cRSElapsedTime;
		this.airTime = airTime;
		this.arrDelay = arrDelay;
		this.depDelay = depDelay;
		this.origin = origin;
		this.dest = dest;
		this.distance = distance;
		this.taxiIn = taxiIn;
		this.taxiOut = taxiOut;
		this.cancelled = cancelled;
		this.cancellationCode = cancellationCode;
		this.diverted = diverted;
		this.carrierDelay = carrierDelay;
		this.weatherDelay = weatherDelay;
		this.nASDelay = nASDelay;
		this.securityDelay = securityDelay;
		this.lateAircraftDelay = lateAircraftDelay;
	}

	/**
	 * 
	 */
	public AirlineDTO() {
	}

	@Override
	public String toString() {
		return "AirlineDTO [year=" + year + ", month=" + month + ", dayofMonth=" + dayofMonth + ", dayOfWeek="
				+ dayOfWeek + ", depTime=" + depTime + ", cRSDepTime=" + cRSDepTime + ", arrTime=" + arrTime
				+ ", cRSArrTime=" + cRSArrTime + ", uniqueCarrier=" + uniqueCarrier + ",flightNum=" + flightNum
				+ ", tailNum=" + tailNum + ", actualElapsedTime=" + dayofMonth + ", dayOfWeek=" + dayOfWeek
				+ ", depTime=" + depTime + ", cRSDepTime=" + cRSDepTime + ", arrTime=" + actualElapsedTime
				+ ", cRSElapsedTime=" + cRSElapsedTime + ", airTime=" + airTime + ",arrDelay=" + arrDelay
				+ ", depDelay=" + depDelay + ", origin=" + dayofMonth + ", dayOfWeek=" + dayOfWeek + ", depTime="
				+ depTime + ", cRSDepTime=" + cRSDepTime + ", arrTime=" + origin + ", dest=" + dest + ", distance="
				+ distance + ",taxiIn=" + taxiIn + ", taxiOut=" + taxiOut + ", cancelled=" + cancelled
				+ ", cancellationCode=" + cancellationCode + ", diverted=" + diverted + ",carrierDelay=" + carrierDelay
				+ ", weatherDelay=" + weatherDelay + ", nASDelay=" + nASDelay + ", securityDelay=" + securityDelay
				+ ", lateAircraftDelay=" + lateAircraftDelay + "]";
	}
}
