//Which carrier performs better?
//updated Oct 2022

package airline

import org.apache.spark.sql._
import org.apache.spark.sql.SQLContext
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{StructType, StructField, StringType}
import scala.util.matching.Regex
import java.net.URLDecoder
import java.util.Arrays
import java.util.Date
import java.util.Calendar
import java.text.SimpleDateFormat
import org.apache.hadoop.fs.FileSystem._


object Airline {
  def main(args: Array[String]) {

    val conf = new SparkConf().setAppName("airline").setMaster("local")
    val sc = new SparkContext(conf)
    val sqlContext = new org.apache.spark.sql.SQLContext(sc);
    import sqlContext.implicits._


    //zeppline or spark shell
    
    //val air = sc.textFile("hdfs:/airline/2007.csv")
    val air = sc.textFile("file:///home/hadoop/2007.csv")

    val df = sqlContext.read.format("csv").option("header", "true").load("file:///home/hadoop/2007.csv")
    
    df.select("year","month","dayofmonth").write.format("jdbc").option("url", "jdbc:postgresql://192.168.29.150:5432/test").option("driver", "org.postgresql.Driver").option("dbtable", "airline").option("user", "postgres").option("password", "postgres").save()

  } //main
} //Class
